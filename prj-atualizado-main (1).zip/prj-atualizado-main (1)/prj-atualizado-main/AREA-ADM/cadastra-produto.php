<?php

$produto = $_POST['produto'];
$categoria = $_POST['categoria'];
$preco = $_POST['preco'];
$nomeFoto = $_FILES['foto']['name'];

move_uploaded_file($_FILES['foto']['tmp_name'], '../img/'.$nomeFoto);

include_once "../Conexao.php";

$pdo = Conexao::conectar();

$stmt = $pdo->prepare("insert into tbproduto ( idProduto, nomeProduto, precoProduto, idCategoria, fotoProduto ) values
(null, '$produto', '$preco', '$categoria', '$nomeFoto' )");

$stmt->execute();

header("location: produto.php")

?>