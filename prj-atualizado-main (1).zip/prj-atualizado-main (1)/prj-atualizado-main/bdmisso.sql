-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 07-Dez-2022 às 18:40
-- Versão do servidor: 10.4.22-MariaDB
-- versão do PHP: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bdmisso`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbcategoria`
--

CREATE TABLE `tbcategoria` (
  `idCategoria` int(11) NOT NULL,
  `cateegoria` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tbcategoria`
--

INSERT INTO `tbcategoria` (`idCategoria`, `cateegoria`) VALUES
(1, 'Sushi'),
(12, 'Empanado'),
(13, 'Urimaki'),
(14, 'Sashimi'),
(15, 'Macarrao'),
(16, 'Temaki'),
(17, 'Sunomono'),
(18, 'Tepan'),
(19, 'Harumaki'),
(20, 'Combos');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbcliente`
--

CREATE TABLE `tbcliente` (
  `idCliente` int(11) NOT NULL,
  `nomeCliente` varchar(80) NOT NULL,
  `cpfCliente` varchar(12) NOT NULL,
  `emailCliente` varchar(100) NOT NULL,
  `senhaCliente` varchar(80) NOT NULL,
  `logradouroCliente` varchar(80) NOT NULL,
  `numLogCliente` int(11) NOT NULL,
  `compCliente` varchar(80) NOT NULL,
  `bairroCliente` varchar(50) NOT NULL,
  `cidadeCliente` varchar(50) NOT NULL,
  `ufCliente` varchar(2) NOT NULL,
  `cepCliente` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tbcliente`
--

INSERT INTO `tbcliente` (`idCliente`, `nomeCliente`, `cpfCliente`, `emailCliente`, `senhaCliente`, `logradouroCliente`, `numLogCliente`, `compCliente`, `bairroCliente`, `cidadeCliente`, `ufCliente`, `cepCliente`) VALUES
(2, 'Ana Beatriz', '13232', 'ana.beatriz@gmail.com', '1234', 'gfgf', 20, 'bloco 03', 'vila urupa', 'suzano', 'GO', '566565'),
(3, 'Fernanda', '565656', 'fernanda.souza@gmail.com', '12345678', 'vcasa joana', 20, '', 'casa da joana', 'suzano', 'GO', '806');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbproduto`
--

CREATE TABLE `tbproduto` (
  `idproduto` int(11) NOT NULL,
  `nomeProduto` varchar(80) DEFAULT NULL,
  `precoProduto` float DEFAULT NULL,
  `fotoProduto` varchar(220) NOT NULL,
  `idCategoria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tbproduto`
--

INSERT INTO `tbproduto` (`idproduto`, `nomeProduto`, `precoProduto`, `fotoProduto`, `idCategoria`) VALUES
(10, 'Acelga-Maki', 35, 'Acelga-Maki.png', 1),
(11, 'Camarão Empanado', 37, 'camarao-empanado.png', 12),
(12, 'Futomaki', 25, 'Futomaki.png', 1),
(13, 'Hot Roll', 25, 'hotroll.png', 12),
(14, 'Sashimi de Polvo', 80, 'sashimi-de-polvo.png', 14),
(15, 'Temaki', 15, 'Temaki.png', 16),
(16, 'Tepan de Salmão', 25, 'Tepan-de-Salmao.jpeg', 18),
(17, 'Urumaki', 25, 'uramaki.png', 13),
(18, 'Yakissoba', 35, 'yakissoba.jpeg', 15),
(20, 'Sunomono', 20, 'Sunomono.jpg', 17),
(21, 'Harumaki de frango', 25, 'harumaki.png', 19),
(22, 'Sashimi de salmão', 33, 'sashimi.jpg', 14),
(23, 'Combo 20 unidades', 42, 'combo3.png', 20),
(24, 'Combo 35 unidades', 54, 'japa.jpg', 20),
(25, 'Combo 45 unidades', 62, 'combo1.jpg', 20),
(26, 'combo 60 unidades', 72, 'combo2.jpg', 20);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tbcategoria`
--
ALTER TABLE `tbcategoria`
  ADD PRIMARY KEY (`idCategoria`);

--
-- Índices para tabela `tbcliente`
--
ALTER TABLE `tbcliente`
  ADD PRIMARY KEY (`idCliente`);

--
-- Índices para tabela `tbproduto`
--
ALTER TABLE `tbproduto`
  ADD PRIMARY KEY (`idproduto`),
  ADD KEY `idCategoria` (`idCategoria`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tbcategoria`
--
ALTER TABLE `tbcategoria`
  MODIFY `idCategoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de tabela `tbcliente`
--
ALTER TABLE `tbcliente`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `tbproduto`
--
ALTER TABLE `tbproduto`
  MODIFY `idproduto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `tbproduto`
--
ALTER TABLE `tbproduto`
  ADD CONSTRAINT `categoria ` FOREIGN KEY (`idCategoria`) REFERENCES `tbcategoria` (`idCategoria`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
